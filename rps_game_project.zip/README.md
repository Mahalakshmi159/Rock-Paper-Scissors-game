# Rock, Paper, Scissors Game

This is a **Python-based Rock, Paper, Scissors game** where you can play against the computer.  
The game provides a **menu system** with options to play, view the scoreboard, reset scores, and exit.  

---

## Features
- Interactive menu system  
- Play Rock, Paper, or Scissors against the computer  
- Computer makes random choices for fairness  
- Scoreboard keeps track of wins, losses, and ties  
- Option to reset scoreboard at any time  
- Clean exit option  

---

## Technologies Used
- Python 3.x  
- Random Module (for computer choices)  

---

## How to Run
1. Save the file as `rps_game.py`.  
2. Open a terminal in the same folder.  
3. Run the game:
   ```bash
   python rps_game.py
   ```

---

## Menu Options
1. Play a Round – Enter Rock, Paper, or Scissors to compete with the computer  
2. View Scoreboard – Displays total wins, losses, ties, and games played  
3. Reset Scoreboard – Resets all scores to zero  
4. Exit Game – Quits the program gracefully  

---

## Example Output
```
===== ROCK, PAPER, SCISSORS GAME =====
1. Play a Round
2. View Scoreboard
3. Reset Scoreboard
4. Exit Game
======================================
Choose an option (1-4): 1

Enter your choice (Rock, Paper, Scissors): rock
You chose: Rock
Computer chose: Paper
Computer wins this round!

===== SCOREBOARD =====
Player Wins   : 0
Computer Wins : 1
Ties          : 0
Total Games   : 1
======================
```

---

## Future Enhancements
- Add a GUI version using Tkinter or Pygame  
- Add multiplayer support  
- Save scoreboard across sessions  
